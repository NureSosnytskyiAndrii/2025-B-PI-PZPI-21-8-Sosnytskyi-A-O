<?php

namespace Database\Factories;

use App\Models\ServiceStation;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Mechanic>
 */
class MechanicFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'station_id' => ServiceStation::factory(),
            'name' => $this->faker->name(),
            'specialization' => $this->faker->randomElement(['Engine', 'Brakes', 'Suspension']),
            'experience_years' => $this->faker->numberBetween(1, 20),
        ];
    }
}
