<?php

namespace Database\Factories;

use App\Models\ServiceStation;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Service>
 */
class ServiceFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'station_id' => ServiceStation::factory(),
            'name' => $this->faker->randomElement(['Oil Change', 'Tire Replacement', 'Brake Check']),
            'description' => $this->faker->sentence(),
            'duration' => $this->faker->randomElement([30, 45, 60]),
            'cost' => $this->faker->numberBetween(300, 1200),
        ];
    }
}
