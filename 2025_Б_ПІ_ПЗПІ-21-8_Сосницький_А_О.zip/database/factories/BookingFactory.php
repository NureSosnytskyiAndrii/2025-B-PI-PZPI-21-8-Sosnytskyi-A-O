<?php

namespace Database\Factories;

use App\Models\User;
use App\Models\Car;
use App\Models\Service;
use App\Models\ServiceStation;
use App\Models\Mechanic;
use Illuminate\Support\Carbon;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Booking>
 */
class BookingFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $date = fake()->dateTimeBetween('+1 day', '+1 week');

        return [
            'user_id' => User::factory(),
            'car_id' => Car::factory(),
            'service_id' => Service::factory(),
            'station_id' => ServiceStation::factory(),
            'mechanic_id' => Mechanic::factory(),
            'date_time' => Carbon::instance($date),
            'status' => fake()->randomElement(['pending', 'in_progress', 'completed']),
        ];
    }
}
