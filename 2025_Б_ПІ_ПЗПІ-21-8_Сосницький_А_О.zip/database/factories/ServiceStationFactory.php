<?php

namespace Database\Factories;

use App\Models\ServiceStation;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\ServiceStation>
 */
class ServiceStationFactory extends Factory
{
    protected $model = ServiceStation::class;

    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name' => fake()->company(),
            'address' => fake()->address(),
            'contact_info' => fake()->phoneNumber(),
            'rating' => fake()->randomFloat(1, 3, 5),
            'user_id' => User::factory(),
        ];
    }
}
