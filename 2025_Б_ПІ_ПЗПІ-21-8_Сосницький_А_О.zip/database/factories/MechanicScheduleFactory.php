<?php

namespace Database\Factories;

use App\Models\Mechanic;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\MechanicSchedule>
 */
class MechanicScheduleFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'mechanic_id' => Mechanic::factory(),
            'date' => $this->faker->dateTimeBetween('today', '+1 week')->format('Y-m-d'),
            'start_time' => '08:00:00',
            'end_time' => '17:00:00',
            'availability_status' => 'available',
        ];
    }
}
