<?php

namespace Database\Factories;

use App\Models\ServiceStation;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\StationOperatingHour>
 */
class StationOperatingHourFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'station_id' => ServiceStation::factory(),
            'day_of_week' => $this->faker->dayOfWeek(),
            'opening_time' => '08:00',
            'closing_time' => '18:00',
        ];
    }
}
