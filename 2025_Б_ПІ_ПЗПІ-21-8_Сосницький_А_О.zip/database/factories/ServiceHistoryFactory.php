<?php

namespace Database\Factories;

use App\Models\Car;
use App\Models\Service;
use App\Models\ServiceStation;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\ServiceHistory>
 */
class ServiceHistoryFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'user_id' => User::factory(),
            'car_id' => Car::factory(),
            'station_id' => ServiceStation::factory(),
            'service_id' => Service::factory(),
            'date' => $this->faker->date(),
            'outcome' => $this->faker->sentence(),
        ];
    }
}
