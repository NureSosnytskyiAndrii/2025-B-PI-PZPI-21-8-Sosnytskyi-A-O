<?php

namespace Database\Factories;

use App\Models\Car;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\CarSpecification>
 */
class CarSpecificationFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'car_id' => Car::factory(),
            'horsepower' => $this->faker->numberBetween(80, 300),
            'torque' => $this->faker->numberBetween(100, 500),
            'fuel_capacity' => $this->faker->randomFloat(1, 30, 80),
            'mileage' => $this->faker->randomFloat(1, 10000, 300000),
            'weight' => $this->faker->randomFloat(1, 800, 3000),
        ];
    }
}
