<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\Mechanic;
use App\Models\ServiceHistory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ServiceHistoryController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'booking_id' => 'required|exists:bookings,booking_id',
            'outcome' => 'nullable|string|max:255',
        ]);

        $user = auth()->user();

        $mechanic = Mechanic::where('name', $user->name)->first();

        if (!$mechanic) {
            return response()->json(['error' => 'Mechanic profile not found'], 403);
        }

        $booking = Booking::where('booking_id', $validated['booking_id'])
            ->where('mechanic_id', $mechanic->mechanic_id)
            ->first();

        if (!$booking) {
            return response()->json(['error' => 'Booking not found or not assigned to you'], 403);
        }

        $history = ServiceHistory::create([
            'user_id' => $booking->user_id,
            'car_id' => $booking->car_id,
            'station_id' => $booking->station_id,
            'service_id' => $booking->service_id,
            'date' => now()->toDateString(),
            'outcome' => $validated['outcome'],
        ]);

        return response()->json([
            'message' => 'Service history entry created by mechanic',
            'history' => $history,
        ], 201);
    }

    public function index()
    {
        $history = ServiceHistory::with(['car', 'service', 'station'])
            ->where('user_id', Auth::id())
            ->orderBy('date', 'desc')
            ->get();

        return response()->json(['history' => $history]);
    }
}
