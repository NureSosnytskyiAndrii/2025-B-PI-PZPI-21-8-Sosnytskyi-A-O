<?php

namespace App\Http\Controllers\API;

use App\Models\Car;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CarController extends Controller
{
    public function index(): \Illuminate\Http\JsonResponse
    {
        $cars = Car::where('user_id', auth()->id())->get();

        return response()->json([
            'cars' => $cars
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'make' => 'required|string|max:50',
            'model' => 'required|string|max:50',
            'year' => 'required|integer|min:1900|max:' . date('Y'),
            'license_plate' => 'required|string|max:20|unique:cars,license_plate',
            'color' => 'required|string|max:30',
            'engine_type' => 'required|string|max:30',
            'transmission' => 'required|string|max:30',
        ]);

        $car = Car::create([
            'user_id' => auth()->id(),
            ...$validated
        ]);

        return response()->json([
            'message' => 'A vehicle added successfully!',
            'car' => $car
        ], 201);
    }

    public function update(Request $request, $id)
    {
        $car = Car::where('car_id', $id)->where('user_id', auth()->id())->first();

        if (!$car) {
            return response()->json(['error' => 'The vehicle not found or does not belong to you'], 404);
        }

        $validated = $request->validate([
            'make' => 'sometimes|string|max:50',
            'model' => 'sometimes|string|max:50',
            'year' => 'sometimes|integer|min:1900|max:' . date('Y'),
            'license_plate' => 'sometimes|string|max:20',
            'color' => 'sometimes|string|max:30',
            'engine_type' => 'sometimes|string|max:30',
            'transmission' => 'sometimes|string|max:30',
        ]);

        $car->update($validated);

        return response()->json([
            'message' => 'The vehicle was successfully updated!',
            'car' => $car
        ]);
    }

    public function destroy($id)
    {
        $car = Car::where('car_id', $id)->where('user_id', auth()->id())->first();

        if (!$car) {
            return response()->json(['error' => 'The vehicle not found or does not belong to you'], 404);
        }

        $car->delete();

        return response()->json(['message' => 'The vehicle deleted successfully!']);
    }
}

