<?php

namespace App\Http\Controllers\API\Admin;

use App\Http\Controllers\Controller;
use App\Models\ServiceStation;
use Illuminate\Http\Request;

class ServiceStationController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:100',
            'address' => 'required|string|max:255',
            'contact_info' => 'required|string|max:255',
            'rating' => 'nullable|numeric|min:0|max:5',
            'user_id' => 'required|numeric|min:1',
        ]);

        $existingStation = ServiceStation::where('user_id', $validated['user_id'])->first();

        if ($existingStation) {
            return response()->json([
                'message' => 'This user already owns a service station. Only one station per user is allowed.'
            ], 422);
        }

        $station = ServiceStation::create($validated);

        return response()->json([
            'message' => 'Service station successfully created!',
            'station' => $station
        ], 201);
    }

    public function index(): \Illuminate\Http\JsonResponse
    {
        $service_station = ServiceStation::all();

        if ($service_station->isEmpty()) {
            return response()->json(['notice' => 'Service stations not found']);
        }

        return response()->json([
            'stations' => $service_station
        ], 201);
    }

    public function update(Request $request, $id): \Illuminate\Http\JsonResponse
    {
        $station = ServiceStation::find($id);

        if (!$station) {
            return response()->json(['error' => 'Service station not found'], 404);
        }

        $validated = $request->validate([
            'name' => 'sometimes|string|max:100',
            'address' => 'sometimes|string|max:255',
            'contact_info' => 'sometimes|string|max:255',
            'rating' => 'sometimes|numeric|min:0|max:5',
        ]);

        $station->update($validated);

        return response()->json([
            'message' => 'Service station updated successfully',
            'station' => $station
        ]);
    }

    public function destroy($id): \Illuminate\Http\JsonResponse
    {
        $station = ServiceStation::find($id);

        if (!$station) {
            return response()->json(['error' => 'Service station not found'], 404);
        }

        $station->delete();

        return response()->json([
            'message' => 'Service station deleted successfully'
        ]);
    }

    public function myStation(): \Illuminate\Http\JsonResponse
    {
        $stations = ServiceStation::where('user_id', auth()->id())->with('operatingHours')->first();

        if (!$stations) {
            return response()->json(['error' => 'Station not found'], 404);
        }

        return response()->json(['station' => $stations]);
    }

    public function search(Request $request): \Illuminate\Http\JsonResponse
    {
        $query = ServiceStation::query();

        if ($request->filled('name')) {
            $query->where('name', 'like', '%' . $request->name . '%');
        }

        if ($request->filled('address')) {
            $query->where('address', 'like', '%' . $request->address . '%');
        }

        if ($request->filled('min_rating')) {
            $query->where('rating', '>=', $request->min_rating);
        }

        if ($request->filled('max_rating')) {
            $query->where('rating', '<=', $request->max_rating);
        }

        $results = $query->with('operatingHours')->get();

        if ($results->isEmpty()) {
            return response()->json(['notice' => 'No service stations found matching criteria'], 404);
        }

        return response()->json(['stations' => $results]);
    }

    public function popularStations()
    {
        $popularStations = ServiceStation::orderByDesc('rating')
            ->limit(5)
            ->get(['station_id', 'name', 'address']);

        return response()->json(['stations' => $popularStations]);
    }

}
