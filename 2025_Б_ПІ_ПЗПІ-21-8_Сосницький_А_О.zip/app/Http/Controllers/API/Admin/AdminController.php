<?php

namespace App\Http\Controllers\API\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;

class AdminController extends Controller
{
    public function index(): \Illuminate\Http\JsonResponse
    {
        return response()->json([
            'message' => 'Admin-panel',
            'users' => User::all()
        ]);
    }

    public function getTechAdmins(): \Illuminate\Http\JsonResponse
    {
        $users = User::select('user_id', 'email')
            ->where('role', 'admin_sto')
            ->get();

        return response()->json([
            'users' => $users
        ]);
    }

    public function updateUserRole($userId)
    {
        if (auth()->id() == $userId) {
            return response()->json([
                'error' => 'You can not change own role!'
            ], 403);
        }

        $user = User::findOrFail($userId);
        $user->role = request('role');
        $user->save();

        return response()->json([
            'message' => 'User\'s role updated successfully',
            'user' => $user
        ]);
    }
}

