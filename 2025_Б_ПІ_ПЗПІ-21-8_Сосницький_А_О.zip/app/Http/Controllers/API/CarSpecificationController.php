<?php
namespace App\Http\Controllers\API;

use App\Models\Car;
use App\Models\CarSpecification;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CarSpecificationController extends Controller
{
    public function store(Request $request, $car_id): \Illuminate\Http\JsonResponse
    {
        $car = Car::where('car_id', $car_id)->where('user_id', auth()->id())->first();

        if (!$car) {
            return response()->json(['error' => 'The vehicle not found or does not belong to you'], 404);
        }

        $validated = $request->validate([
            'horsepower' => 'required|integer|min:1',
            'torque' => 'required|integer|min:1',
            'fuel_capacity' => 'required|numeric|min:0',
            'mileage' => 'required|numeric|min:0',
            'weight' => 'required|numeric|min:0',
        ]);

        $spec = CarSpecification::create([
            'car_id' => $car->car_id,
            ...$validated
        ]);

        return response()->json([
            'message' => 'Specification saved successfully',
            'specification' => $spec
        ], 201);
    }

    public function show($car_id)
    {
        $car = Car::where('car_id', $car_id)->where('user_id', auth()->id())->first();

        if (!$car) {
            return response()->json(['error' => 'The vehicle not found or it does not belong to you'], 404);
        }

        $spec = CarSpecification::where('car_id', $car->car_id)->first();

        return response()->json([
            'specification' => $spec
        ]);
    }

    public function update(Request $request, $car_id)
    {
        $spec = CarSpecification::where('car_id', $car_id)->first();

        if (!$spec || $spec->car->user_id !== auth()->id()) {
            return response()->json(['error' => 'Access forbidden or specification not found'], 403);
        }

        $validated = $request->validate([
            'horsepower' => 'sometimes|integer|min:1',
            'torque' => 'sometimes|integer|min:1',
            'fuel_capacity' => 'sometimes|numeric|min:0',
            'mileage' => 'sometimes|numeric|min:0',
            'weight' => 'sometimes|numeric|min:0',
        ]);

        $spec->update($validated);

        return response()->json([
            'message' => 'Specification updated successfully',
            'specification' => $spec
        ]);
    }

    public function destroy($car_id)
    {
        $spec = CarSpecification::where('car_id', $car_id)->first();

        if (!$spec || $spec->car->user_id !== auth()->id()) {
            return response()->json(['error' => 'Access forbidden or specification not found'], 403);
        }

        $spec->delete();

        return response()->json(['message' => 'Specification deleted successfully!']);
    }
}
