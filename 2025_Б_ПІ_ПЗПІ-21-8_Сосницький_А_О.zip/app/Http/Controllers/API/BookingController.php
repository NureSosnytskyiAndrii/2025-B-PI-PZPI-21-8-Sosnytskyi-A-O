<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\Mechanic;
use App\Models\MechanicSchedule;
use App\Models\Service;
use App\Models\ServiceStation;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Auth;

class BookingController extends Controller
{

    public function store(Request $request)
    {
        $request->validate([
            'car_id' => 'required|exists:cars,car_id',
            'service_id' => 'required|exists:services,service_id',
            'station_id' => 'required|exists:service_stations,station_id',
            'date_time' => 'required|date|after_or_equal:today',
        ]);

        $dateTime = Carbon::parse($request->date_time);
        $date = $dateTime->toDateString();
        $time = $dateTime->format('H:i:s');

        $service = Service::find($request->service_id);
        if (!$service || !$service->duration) {
            return response()->json(['error' => 'Invalid or missing service duration'], 422);
        }

        $durationMinutes = $service->duration;
        $endDateTime = $dateTime->copy()->addMinutes($durationMinutes);

        $availableMechanicIds = MechanicSchedule::where('date', $date)
            ->where('start_time', '<=', $time)
            ->where('end_time', '>=', $endDateTime->format('H:i:s'))
            ->where('availability_status', 'available')
            ->whereHas('mechanic', function ($q) use ($request) {
                $q->where('station_id', $request->station_id);
            })
            ->pluck('mechanic_id');

        if ($availableMechanicIds->isEmpty()) {
            return response()->json(['error' => 'There are no available mechanics for the selected time'], 422);
        }

        $conflictingMechanicId = Booking::join('services', 'bookings.service_id', '=', 'services.service_id')
            ->whereIn('bookings.mechanic_id', $availableMechanicIds)
            ->whereDate('bookings.date_time', $date)
            ->where(function ($q) use ($dateTime, $endDateTime) {
                $q->whereBetween('bookings.date_time', [$dateTime, $endDateTime])
                ->orWhereRaw('? BETWEEN bookings.date_time AND DATE_ADD(bookings.date_time, INTERVAL services.duration MINUTE)', [$dateTime]); // новий початок в старому інтервалі
            })
            ->value('bookings.mechanic_id');

        if ($conflictingMechanicId) {
            return response()->json(['error' => 'All mechanics are busy at the selected time'], 422);
        }

        $freeMechanicId = $availableMechanicIds->first();

        $booking = Booking::create([
            'user_id' => auth()->id(),
            'car_id' => $request->car_id,
            'service_id' => $request->service_id,
            'station_id' => $request->station_id,
            'mechanic_id' => $freeMechanicId,
            'date_time' => $request->date_time,
            'status' => 'pending',
        ]);

        $user = auth()->user();
        $station = ServiceStation::find($request->station_id);
        $mechanic = Mechanic::find($freeMechanicId);

        Mail::html("
        <h2>Your booking is <strong>confirmed</strong>.</h2>
        <p><strong>Date:</strong> {$booking->date_time}</p>
        <p><strong>Service station:</strong> {$station->name}</p>
        <p><strong>Mechanic:</strong> {$mechanic->name}</p>
        <p><strong>Service:</strong> {$service->name}</p>
        <p><strong>Status:</strong> {$booking->status}</p>
    ", function ($message) use ($user) {
            $message->to($user->email)
                ->subject('Service booking confirmation');
        });

        return response()->json([
            'message' => 'Booking successfully created and confirmation email sent',
            'booking' => $booking
        ], 201);
    }

    public function index()
    {
        $bookings = Booking::with(['car', 'service', 'station', 'mechanic'])
            ->where('user_id', Auth::id())
            ->orderBy('date_time', 'desc')
            ->get();

        return response()->json($bookings);
    }

    public function show($id)
    {
        $booking = Booking::with(['car', 'service', 'station', 'mechanic'])
            ->where('user_id', Auth::id())
            ->where('booking_id', $id)
            ->first();

        if (!$booking) {
            return response()->json(['error' => 'Booking not found or not belongs to you'], 404);
        }

        return response()->json($booking);
    }

    public function destroy($id)
    {
        $booking = Booking::where('user_id', Auth::id())
            ->where('booking_id', $id)
            ->first();

        if (!$booking) {
            return response()->json(['error' => 'Booking not found or not belong to you'], 404);
        }

        if (in_array($booking->status, ['completed', 'cancelled'])) {
            return response()->json(['error' => 'This booking has already been completed or canceled and cannot be deleted'], 403);
        }

        $booking->delete();

        return response()->json(['message' => 'Booking successfully cancelled']);
    }
}

