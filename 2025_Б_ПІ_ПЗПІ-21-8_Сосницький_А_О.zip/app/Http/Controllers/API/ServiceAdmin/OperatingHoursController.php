<?php

namespace App\Http\Controllers\API\ServiceAdmin;

use App\Http\Controllers\Controller;
use App\Models\ServiceStation;
use App\Models\StationOperatingHour;
use Illuminate\Http\Request;

class OperatingHoursController extends Controller
{
    public function index()
    {
        $station = ServiceStation::where('user_id', auth()->id())->first();

        if (!$station) {
            return response()->json(['error' => 'Service station not found'], 404);
        }

        return response()->json(['hours' => $station->operatingHours]);
    }

    public function store(Request $request)
    {
        $station = ServiceStation::where('user_id', auth()->id())->first();

        if (!$station) {
            return response()->json(['error' => 'Service station not found'], 404);
        }

        $validated = $request->validate([
            'day_of_week' => 'required|string|in:Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday',
            'opening_time' => 'required|date_format:H:i',
            'closing_time' => 'required|date_format:H:i|after:opening_time',
        ]);

        $hour = StationOperatingHour::create([
            'station_id' => $station->station_id,
            ...$validated
        ]);

        return response()->json([
            'message' => 'Working hours were added',
            'hour' => $hour
        ]);
    }

    public function update(Request $request, $id)
    {
        $hour = StationOperatingHour::findOrFail($id);

        if ($hour->station->user_id !== auth()->id()) {
            return response()->json(['error' => 'Access forbidden'], 403);
        }

        $validated = $request->validate([
            'opening_time' => 'sometimes|date_format:H:i',
            'closing_time' => 'sometimes|date_format:H:i|after:opening_time',
        ]);

        $hour->update($validated);

        return response()->json(['message' => 'Working hours successfully updated', 'hour' => $hour]);
    }

    public function destroy($id)
    {
        $hour = StationOperatingHour::findOrFail($id);

        if ($hour->station->user_id !== auth()->id()) {
            return response()->json(['error' => 'Access forbidden'], 403);
        }

        $hour->delete();

        return response()->json(['message' => 'Working hours deleted successfully']);
    }
}
