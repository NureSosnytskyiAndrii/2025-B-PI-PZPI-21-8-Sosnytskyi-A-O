<?php

namespace App\Http\Controllers\API\ServiceAdmin;

use App\Http\Controllers\Controller;
use App\Models\Booking;
use App\Models\ServiceStation;
use App\Models\User;
use App\Models\Mechanic;
use Illuminate\Http\Request;
use App\Models\MechanicSchedule;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Mail;

class MechanicController extends Controller
{
    public function getMechanics()
    {
        $station = ServiceStation::where('user_id', auth()->id())->first();
        if (!$station) {
            return response()->json(['error' => 'Service station not found'], 404);
        }

        $mechanics = Mechanic::where('station_id', $station->station_id)->get();

        return response()->json(['mechanics' => $mechanics]);
    }

    public function getSchedule($mechanic_id)
    {
        $station = ServiceStation::where('user_id', auth()->id())->first();

        if (!$station) {
            return response()->json(['error' => 'Service station not found'], 404);
        }

        $mechanic = Mechanic::where('mechanic_id', $mechanic_id)
            ->where('station_id', $station->station_id)
            ->first();

        if (!$mechanic) {
            return response()->json(['error' => 'Mechanic not found or does not belong to your station'], 404);
        }

        $schedule = MechanicSchedule::where('mechanic_id', $mechanic_id)->orderBy('date')->get();

        return response()->json(['schedule' => $schedule]);
    }

    public function getSingleSchedule($id)
    {
        $station = ServiceStation::where('user_id', auth()->id())->first();

        if (!$station) {
            return response()->json(['error' => 'Service station not found'], 404);
        }

        $schedule = MechanicSchedule::find($id);

        if (!$schedule) {
            return response()->json(['error' => 'Schedule not found'], 404);
        }

        $mechanic = Mechanic::find($schedule->mechanic_id);

        if (!$mechanic || $mechanic->station_id !== $station->station_id) {
            return response()->json(['error' => 'This schedule does not belong to your station'], 403);
        }

        return response()->json(['schedule' => $schedule]);
    }

    public function profile()
    {
        $user = auth()->user();

        $mechanic = Mechanic::where('name', $user->name)->first();
        if (!$mechanic) {
            return response()->json(['error' => 'Mechanic profile not found'], 404);
        }

        $station = ServiceStation::find($mechanic->station_id);

        return response()->json([
            'mechanic' => [
                'name' => $mechanic->name,
                'specialization' => $mechanic->specialization,
                'experience_years' => $mechanic->experience_years,
            ],
            'station' => [
                'station_id' => $station->station_id,
                'name' => $station->name,
                'address' => $station->address,
                'contact_info' => $station->contact_info ?? null,
                'rating' => $station->rating ?? null,
            ]
        ]);
    }

    public function getMechanicUsers()
    {
        $mechanics = User::where('role', 'mechanic')->get(['user_id', 'email']);
        return response()->json(['mechanics' => $mechanics]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'user_id' => 'required|exists:users,user_id',
            'specialization' => 'required|string|max:100',
            'experience_years' => 'required|integer|min:0|max:70'
        ]);

        $user = User::find($validated['user_id']);
        if ($user->role !== 'mechanic') {
            return response()->json(['error' => 'User is not a mechanic'], 422);
        }

        $station = ServiceStation::where('user_id', auth()->id())->first();
        if (!$station) {
            return response()->json(['error' => 'Service station not found or not belong to you'], 403);
        }

        $exists = Mechanic::where('station_id', $station->station_id)
            ->where('name', $user->name)
            ->first();

        if ($exists) {
            return response()->json(['error' => 'This mechanic already added to service station'], 409);
        }

        $mechanic = Mechanic::create([
            'station_id' => $station->station_id,
            'name' => $user->name,
            'specialization' => $validated['specialization'],
            'experience_years' => $validated['experience_years'],
        ]);

        return response()->json([
            'message' => 'The mechanic was successfully added to service station',
            'mechanic' => $mechanic,
            'station' => $station,
        ], 201);
    }

    public function storeSchedule(Request $request)
    {
        $validated = $request->validate([
            'mechanic_id' => 'required|exists:mechanics,mechanic_id',
            'date' => 'required|date',
            'start_time' => 'required|date_format:H:i',
            'end_time' => 'required|date_format:H:i|after:start_time',
            'availability_status' => 'required|in:available,unavailable',
        ]);

        $station = ServiceStation::where('user_id', auth()->id())->first();

        if (!$station) {
            return response()->json(['error' => 'Service station not found or not owned by you'], 403);
        }

        $mechanic = Mechanic::where('mechanic_id', $validated['mechanic_id'])
            ->where('station_id', $station->station_id)
            ->first();

        if (!$mechanic) {
            return response()->json(['error' => 'This master does not belong to your station'], 403);
        }

        $conflict = MechanicSchedule::where('mechanic_id', $validated['mechanic_id'])
            ->where('date', $validated['date'])
            ->where(function ($query) use ($validated) {
                $query->where('start_time', '<', $validated['end_time'])
                    ->where('end_time', '>', $validated['start_time']);
            })->exists();

        if ($conflict) {
            return response()->json(['error' => 'There is a conflict with an existing schedule for this day'], 409);
        }

        $schedule = MechanicSchedule::create([
            'mechanic_id' => $validated['mechanic_id'],
            'date' => $validated['date'],
            'start_time' => $validated['start_time'],
            'end_time' => $validated['end_time'],
            'availability_status' => $validated['availability_status'],
        ]);

        return response()->json([
            'message' => 'The mechanic\'s schedule created successfully',
            'schedule' => $schedule,
        ], 201);
    }

    public function myBookings()
    {
        $user = auth()->user();
        $mechanic = Mechanic::where('name', $user->name)->first();

        if (!$mechanic) {
            return response()->json(['error' => 'Mechanic profile not found'], 404);
        }

        $bookings = Booking::where('mechanic_id', $mechanic->mechanic_id)
            ->with(['service'])
            ->get();

        return response()->json(['bookings' => $bookings]);
    }

    public function bookingDetails($bookingId)
    {
        $user = auth()->user();
        $mechanic = Mechanic::where('name', $user->name)->first();

        if (!$mechanic) {
            return response()->json(['error' => 'Mechanic profile not found'], 404);
        }

        $booking = Booking::where('booking_id', $bookingId)
            ->where('mechanic_id', $mechanic->mechanic_id)
            ->with(['car', 'service', 'user'])
            ->first();

        if (!$booking) {
            return response()->json(['error' => 'Booking not found or does not belong to you'], 404);
        }

        return response()->json(['booking' => $booking]);
    }

    public function updateBookingStatus(Request $request, $bookingId)
    {
        $request->validate([
            'status' => 'required|in:pending,in_progress,completed,cancelled',
        ]);

        $user = auth()->user();
        $mechanic = Mechanic::where('name', $user->name)->first();

        if (!$mechanic) {
            return response()->json(['error' => 'Mechanic profile not found'], 404);
        }

        $booking = Booking::where('booking_id', $bookingId)
            ->where('mechanic_id', $mechanic->mechanic_id)
            ->first();

        if (!$booking) {
            return response()->json(['error' => 'Booking not found or does not belong to you'], 404);
        }

        $booking->status = $request->status;
        $booking->save();

        $html = "
        <h2>Your booking status was updated</h2>
        <p><strong>booking №:</strong> {$booking->booking_id}</p>
        <p><strong>New status:</strong> {$booking->status}</p>
        <p><strong>Service date:</strong> {$booking->date_time}</p>
        <p><strong>Service station:</strong> {$booking->station->name}</p>
        <p><strong>Mechanic:</strong> {$booking->mechanic->name}</p>
        <p><strong>Service:</strong> {$booking->service->name}</p>
    ";
        Mail::html($html, function ($message) use ($booking) {
            $message->to($booking->user->email)
                ->subject('Your booking status was updated');
        });

        return response()->json(['message' => 'Booking status updated successfully', 'booking' => $booking]);
    }

    public function mySchedule()
    {
        $user = auth()->user();
        $mechanic = Mechanic::where('name', $user->name)->first();

        if (!$mechanic) {
            return response()->json(['error' => 'Mechanic profile not found'], 404);
        }

        $schedules = MechanicSchedule::where('mechanic_id', $mechanic->mechanic_id)->get();

        return response()->json(['schedules' => $schedules]);
    }

    public function deleteSchedule($id)
    {
        $schedule = MechanicSchedule::find($id);

        if (!$schedule) {
            return response()->json(['error' => 'Schedule not found'], 404);
        }

        $station = ServiceStation::where('user_id', auth()->id())->first();

        if (!$station) {
            return response()->json(['error' => 'You do not manage any service station'], 403);
        }

        $mechanic = Mechanic::where('mechanic_id', $schedule->mechanic_id)
            ->where('station_id', $station->station_id)
            ->first();

        if (!$mechanic) {
            return response()->json(['error' => 'This schedule does not belong to your station'], 403);
        }

        $schedule->delete();

        return response()->json(['message' => 'Schedule deleted successfully']);
    }

    public function updateSchedule(Request $request, $id)
    {
        $schedule = MechanicSchedule::findOrFail($id);

        $mechanic = $schedule->mechanic;
        $station = $mechanic->station;

        if (!$station || $station->user_id !== auth()->id()) {
            return response()->json(['error' => 'Access denied.'], 403);
        }

        $validated = $request->validate([
            'date' => 'required|date',
            'start_time' => 'required|date_format:H:i',
            'end_time' => 'required|date_format:H:i|after:start_time',
            'availability_status' => 'required|in:available,busy',
        ]);

        $schedule->update($validated);

        return response()->json([
            'message' => 'Schedule updated successfully',
            'schedule' => $schedule
        ]);
    }
}
