<?php

namespace App\Http\Controllers\API\ServiceAdmin;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Models\ServiceStation;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
    public function store(Request $request)
    {
        $station = ServiceStation::where('user_id', auth()->id())->first();

        if (!$station) {
            return response()->json(['error' => 'Service station not found or not belong to you'], 403);
        }

        $validated = $request->validate([
            'name' => 'required|string|max:100',
            'description' => 'required|string|max:255',
            'duration' => 'required|integer|min:1',
            'cost' => 'required|numeric|min:0',
        ]);

        $service = Service::create([
            'station_id' => $station->station_id,
            ...$validated,
        ]);

        return response()->json([
            'message' => 'Service successfully added',
            'service' => $service,
        ], 201);
    }

    public function index(Request $request)
    {
        $station = ServiceStation::where('user_id', auth()->id())->first();

        if (!$station) {
            return response()->json(['error' => 'Service station not found'], 403);
        }

        return response()->json([
            'services' => $station->services
        ]);
    }

    public function publicServices(Request $request, $stationId)
    {
        $station = ServiceStation::find($stationId);

        if (!$station) {
            return response()->json(['error' => 'Service station not found'], 404);
        }

        $query = $station->services();

        $query->when($request->filled('min_cost'), fn($q) => $q->where('cost', '>=', $request->min_cost))
            ->when($request->filled('max_cost'), fn($q) => $q->where('cost', '<=', $request->max_cost))
            ->when($request->filled('min_duration'), fn($q) => $q->where('duration', '>=', $request->min_duration))
            ->when($request->filled('max_duration'), fn($q) => $q->where('duration', '<=', $request->max_duration));

        if (in_array($request->sort_price, ['asc', 'desc'])) {
            $query->orderBy('cost', $request->sort_price);
        }

        return response()->json([
            'services' => $query->get()
        ]);
    }

    public function update(Request $request, $id)
    {
        $service = Service::findOrFail($id);

        if ($service->station->user_id !== auth()->id()) {
            return response()->json(['error' => 'This service is not belong to you service station'], 403);
        }

        $validated = $request->validate([
            'name' => 'sometimes|string|max:100',
            'description' => 'sometimes|string|max:255',
            'duration' => 'sometimes|integer|min:1',
            'cost' => 'sometimes|numeric|min:0',
        ]);

        $service->update($validated);

        return response()->json([
            'message' => 'Service was successfully updated',
            'service' => $service,
        ]);
    }

    public function destroy($id)
    {
        $service = Service::findOrFail($id);

        if ($service->station->user_id !== auth()->id()) {
            return response()->json(['error' => 'This service is not belong to you service station'], 403);
        }

        $service->delete();

        return response()->json(['message' => 'This service was successfully deleted']);
    }
}
