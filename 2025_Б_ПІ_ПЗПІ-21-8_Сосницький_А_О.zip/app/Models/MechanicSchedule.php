<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Testing\Fluent\Concerns\Has;

class MechanicSchedule extends Model
{
    use HasFactory;
    protected $primaryKey = 'schedule_id';

    protected $fillable = [
        'schedule_id',
        'mechanic_id',
        'date',
        'start_time',
        'end_time',
        'availability_status',
    ];

    public function mechanic()
    {
        return $this->belongsTo(Mechanic::class, 'mechanic_id', 'mechanic_id');
    }

}
