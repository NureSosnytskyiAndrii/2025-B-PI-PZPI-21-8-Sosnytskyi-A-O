<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ServiceStation extends Model
{
    use HasFactory;
    protected $primaryKey = 'station_id';

    protected $fillable = [
        'name',
        'address',
        'contact_info',
        'rating',
        'user_id'
    ];

    public function admin()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function operatingHours()
    {
        return $this->hasMany(StationOperatingHour::class, 'station_id');
    }

    public function services()
    {
        return $this->hasMany(Service::class, 'station_id');
    }


}
