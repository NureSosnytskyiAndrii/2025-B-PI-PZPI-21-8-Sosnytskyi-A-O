<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ServiceHistory extends Model
{
    use HasFactory;
    protected $primaryKey = 'history_id';
    protected $table = 'service_history';

    protected $fillable = [
        'user_id',
        'car_id',
        'station_id',
        'service_id',
        'date',
        'outcome'
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function car()
    {
        return $this->belongsTo(Car::class, 'car_id');
    }

    public function station()
    {
        return $this->belongsTo(ServiceStation::class, 'station_id');
    }

    public function service()
    {
        return $this->belongsTo(Service::class, 'service_id');
    }
}
