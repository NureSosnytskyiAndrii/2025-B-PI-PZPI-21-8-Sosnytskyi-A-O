<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Car extends Model
{
    use HasFactory;

    protected $primaryKey = 'car_id';

    protected $fillable = [
        'user_id',
        'make',
        'model',
        'year',
        'license_plate',
        'color',
        'engine_type',
        'transmission',
    ];

    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
}

