<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Mechanic extends Model
{
    use HasFactory;

    protected $primaryKey = 'mechanic_id';

    protected $fillable = [
        'station_id',
        'name',
        'specialization',
        'experience_years',
    ];

    public function station()
    {
        return $this->belongsTo(ServiceStation::class, 'station_id');
    }

    public function bookings()
    {
        return $this->hasMany(Booking::class, 'mechanic_id');
    }

}
