<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StationOperatingHour extends Model
{
    use HasFactory;

    protected $primaryKey = 'hour_id';

    protected $fillable = [
        'station_id',
        'day_of_week',
        'opening_time',
        'closing_time',
    ];

    public function station()
    {
        return $this->belongsTo(ServiceStation::class, 'station_id');
    }
}
