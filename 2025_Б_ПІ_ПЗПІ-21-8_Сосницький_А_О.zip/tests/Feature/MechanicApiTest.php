<?php

namespace Tests\Feature;

use App\Models\User;
use App\Models\Mechanic;
use App\Models\Booking;
use App\Models\MechanicSchedule;
use App\Models\Service;
use App\Models\Car;
use App\Models\ServiceStation;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class MechanicApiTest extends TestCase
{
    use RefreshDatabase;

    protected $mechanicUser;
    protected $station;
    protected $token;

    protected function setUp(): void
    {
        parent::setUp();

        $station = ServiceStation::factory()->create();
        $this->mechanicUser = User::factory()->create(['role' => 'mechanic']);
        $mechanic = Mechanic::factory()->create([
            'name' => $this->mechanicUser->name,
            'station_id' => $station->station_id
        ]);

        $this->token = auth()->login($this->mechanicUser);
    }

    /** @test */
    public function it_can_view_profile()
    {
        $response = $this->withToken($this->token)
            ->getJson('/api/mechanic/profile');

        $response->assertStatus(200)
            ->assertJsonStructure([
                'mechanic' => ['name', 'specialization', 'experience_years'],
                'station' => ['station_id', 'name', 'address', 'contact_info', 'rating']
            ]);
    }

    /** @test */
    public function it_can_get_bookings()
    {
        $car = Car::factory()->create(['user_id' => $this->mechanicUser->id]);
        $service = Service::factory()->create(['station_id' => $this->station->station_id]);
        $mechanic = Mechanic::where('name', $this->mechanicUser->name)->first();
        Booking::factory()->create([
            'mechanic_id' => $mechanic->mechanic_id,
            'car_id' => $car->car_id,
            'service_id' => $service->service_id
        ]);

        $response = $this->withToken($this->token)
            ->getJson('/api/mechanic/bookings');

        $response->assertStatus(200)
            ->assertJsonStructure([['booking_id', 'date_time', 'status']]);
    }

    /** @test */
    public function it_can_view_booking_details()
    {
        $car = Car::factory()->create(['user_id' => $this->mechanicUser->id]);
        $service = Service::factory()->create();
        $mechanic = Mechanic::where('name', $this->mechanicUser->name)->first();
        $booking = Booking::factory()->create([
            'mechanic_id' => $mechanic->mechanic_id,
            'car_id' => $car->car_id,
            'service_id' => $service->service_id
        ]);

        $response = $this->withToken($this->token)
            ->getJson('/api/mechanic/bookings/' . $booking->booking_id);

        $response->assertStatus(200)
            ->assertJsonStructure(['booking']);
    }

    /** @test */
    public function it_can_update_booking_status()
    {
        $mechanic = Mechanic::where('name', $this->mechanicUser->name)->first();
        $booking = Booking::factory()->create([
            'mechanic_id' => $mechanic->mechanic_id,
            'status' => 'pending'
        ]);

        $response = $this->withToken($this->token)
            ->patchJson("/api/mechanic/bookings/{$booking->booking_id}/status", [
                'status' => 'in_progress'
            ]);

        $response->assertStatus(200)
            ->assertJsonFragment(['message' => 'Status updated']);
    }

    /** @test */
    public function it_can_see_schedule()
    {
        $mechanic = Mechanic::where('name', $this->mechanicUser->name)->first();
        MechanicSchedule::factory()->create([
            'mechanic_id' => $mechanic->mechanic_id
        ]);

        $response = $this->withToken($this->token)
            ->getJson('/api/mechanic/schedule');

        $response->assertStatus(200)
            ->assertJsonStructure(['schedules']);

    }

    /** @test */
    public function it_can_add_service_history()
    {
        $mechanic = Mechanic::where('name', $this->mechanicUser->name)->first();
        $booking = Booking::factory()->create([
            'mechanic_id' => $mechanic->mechanic_id,
        ]);

        $response = $this->withToken($this->token)
            ->postJson('/api/mechanic/service-history', [
                'booking_id' => $booking->booking_id,
                'outcome' => 'Oil changed and tires rotated.'
            ]);

        $response->assertStatus(201)
            ->assertJsonFragment(['message' => 'Service history entry created by mechanic']);
    }
}

