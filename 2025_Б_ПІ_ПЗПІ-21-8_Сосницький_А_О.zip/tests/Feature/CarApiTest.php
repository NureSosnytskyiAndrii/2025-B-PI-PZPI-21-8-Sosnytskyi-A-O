<?php

namespace Tests\Feature;

use App\Models\User;
use App\Models\Car;
use App\Models\CarSpecification;
use App\Models\ServiceHistory;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Str;
use Tests\TestCase;

class CarApiTest extends TestCase
{
    use RefreshDatabase;

    protected $user;
    protected $headers;

    protected function setUp(): void
    {
        parent::setUp();

        $this->user = User::factory()->create([
            'role' => 'user',
            'email_verified_at' => now(),
        ]);

        $token = auth()->login($this->user);
        $this->headers = ['Authorization' => "Bearer $token"];
    }

    public function test_user_can_add_car()
    {
        $data = [
            'make' => 'Toyota',
            'model' => 'Corolla',
            'year' => 2020,
            'license_plate' => strtoupper(Str::random(7)),
            'color' => 'Blue',
            'engine_type' => 'Petrol',
            'transmission' => 'Automatic',
        ];

        $response = $this->postJson('/api/cars', $data, $this->headers);
        $response->assertCreated()
            ->assertJsonStructure(['message', 'car']);
        $this->assertDatabaseHas('cars', ['license_plate' => $data['license_plate']]);
    }

    public function test_user_can_update_car()
    {
        $car = Car::factory()->create(['user_id' => $this->user->id]);

        $response = $this->putJson("/api/cars/{$car->car_id}", [
            'color' => 'Red',
        ], $this->headers);

        $response->assertOk()
            ->assertJsonFragment(['color' => 'Red']);
    }

    public function test_user_can_delete_car()
    {
        $car = Car::factory()->create(['user_id' => $this->user->id]);

        $response = $this->deleteJson("/api/cars/{$car->car_id}", [], $this->headers);
        $response->assertOk()
            ->assertJson(['message' => 'Car deleted successfully']);
        $this->assertDatabaseMissing('cars', ['car_id' => $car->car_id]);
    }

    public function test_user_can_add_and_view_specification()
    {
        $car = Car::factory()->create(['user_id' => $this->user->id]);

        $specData = [
            'horsepower' => 150,
            'torque' => 200,
            'fuel_capacity' => 45.5,
            'mileage' => 120000,
            'weight' => 1300,
        ];

        $addSpec = $this->postJson("/api/cars/{$car->car_id}/specifications", $specData, $this->headers);
        $addSpec->assertCreated()
            ->assertJsonStructure(['message', 'specification']);

        $viewSpec = $this->getJson("/api/cars/{$car->car_id}/specifications", $this->headers);
        $viewSpec->assertOk()
            ->assertJsonFragment(['horsepower' => 150]);
    }

    public function test_user_can_update_and_delete_specification()
    {
        $car = Car::factory()->create(['user_id' => $this->user->id]);
        $spec = CarSpecification::factory()->create(['car_id' => $car->car_id]);

        $response = $this->putJson("/api/cars/{$car->car_id}/specifications", [
            'horsepower' => 180
        ], $this->headers);

        $response->assertOk()
            ->assertJsonFragment(['horsepower' => 180]);

        $delete = $this->deleteJson("/api/cars/{$car->car_id}/specifications", [], $this->headers);
        $delete->assertOk()
            ->assertJson(['message' => 'Specification deleted successfully']);
    }

    public function test_user_can_view_service_history()
    {
        $car = Car::factory()->create(['user_id' => $this->user->id]);
        ServiceHistory::factory()->create([
            'car_id' => $car->car_id,
            'user_id' => $this->user->id,
        ]);

        $response = $this->getJson("/api/cars/service-history", $this->headers);
        $response->assertOk()
            ->assertJsonStructure(['history']);
    }
}
