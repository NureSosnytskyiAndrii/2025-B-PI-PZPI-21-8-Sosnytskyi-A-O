<?php

namespace Tests\Feature;

use App\Models\User;
use App\Models\ServiceStation;
use App\Models\Mechanic;
use App\Models\MechanicSchedule;
use App\Models\Service;
use App\Models\StationOperatingHour;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminStoApiTest extends TestCase
{
    use RefreshDatabase;

    protected function authenticateAdminSto()
    {
        $user = User::factory()->create(['role' => 'admin_sto']);
        $station = ServiceStation::factory()->create(['user_id' => $user->user_id]);

        $token = auth()->login($user);
        return ['Authorization' => "Bearer $token"];
    }

    /** @test */
    public function it_can_fetch_own_station()
    {
        $headers = $this->authenticateAdminSto();
        $response = $this->getJson('/api/admin-sto/station', $headers);
        $response->assertOk()->assertJsonStructure(['station']);
    }

    /** @test */
    public function it_can_manage_operating_hours()
    {
        $headers = $this->authenticateAdminSto();

        $store = $this->postJson('/api/admin-sto/station/hours', [
            'day_of_week' => 'Monday',
            'opening_time' => '08:00',
            'closing_time' => '18:00',
        ], $headers);
        $store->assertCreated()->assertJsonStructure(['message', 'hour']);

        $id = $store['hour']['id'];

        $update = $this->putJson("/api/admin-sto/station/hours/{$id}", [
            'closing_time' => '19:00',
        ], $headers);
        $update->assertOk()->assertJsonFragment(['closing_time' => '19:00']);

        $this->deleteJson("/api/admin-sto/station/hours/{$id}", $headers)->assertOk();
    }

    /** @test */
    public function it_can_add_and_fetch_mechanics()
    {
        $headers = $this->authenticateAdminSto();

        $mechanicUser = User::factory()->create(['role' => 'mechanic']);

        $response = $this->postJson('/api/admin-sto/mechanics', [
            'user_id' => $mechanicUser->user_id,
            'specialization' => 'Brake systems',
            'experience_years' => 5,
        ], $headers);

        $response->assertCreated()->assertJsonStructure(['mechanic']);

        $this->getJson('/api/admin-sto/mechanics', $headers)->assertOk()->assertJsonStructure(['mechanics']);
    }

    /** @test */
    public function it_can_manage_mechanic_schedule()
    {
        $headers = $this->authenticateAdminSto();

        $mechanic = Mechanic::factory()->create();
        $schedule = MechanicSchedule::factory()->create(['mechanic_id' => $mechanic->mechanic_id]);

        $this->putJson("/api/admin-sto/mechanics/schedule/{$schedule->schedule_id}", [
            'start_time' => '10:00:00',
        ], $headers)->assertOk();

        $this->deleteJson("/api/admin-sto/mechanics/schedule/{$schedule->schedule_id}", $headers)->assertOk();
    }

    /** @test */
    public function it_can_manage_services()
    {
        $headers = $this->authenticateAdminSto();

        $store = $this->postJson('/api/admin-sto/services', [
            'name' => 'Oil Change',
            'description' => 'Quick oil change',
            'duration' => 30,
            'cost' => 500,
        ], $headers);
        $store->assertCreated()->assertJsonStructure(['service']);

        $id = $store['service']['service_id'];

        $this->putJson("/api/admin-sto/services/{$id}", [
            'cost' => 550
        ], $headers)->assertOk()->assertJsonFragment(['cost' => 550]);

        $this->deleteJson("/api/admin-sto/services/{$id}", $headers)->assertOk();
    }
}
