<?php
namespace Tests\Feature;

use Database\Factories\ServiceStationFactory;
use Illuminate\Foundation\Testing\RefreshDatabase;
use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;
use App\Models\ServiceStation;

class ServiceStationApiTest extends TestCase
{
    use RefreshDatabase;

    #[Test]
    public function it_returns_popular_service_stations()
    {
        ServiceStation::factory()->count(5)->create();

        $response = $this->getJson('/api/stations/popular');

        $response->assertStatus(200)
            ->assertJsonStructure([
                'stations' => [['station_id', 'name', 'address']]
            ]);
    }
}

