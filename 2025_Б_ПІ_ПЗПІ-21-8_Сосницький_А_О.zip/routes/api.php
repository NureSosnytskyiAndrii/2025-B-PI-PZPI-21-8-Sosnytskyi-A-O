<?php

use App\Http\Controllers\API\Admin\AdminController;
use App\Http\Controllers\API\Admin\ServiceStationController;
use App\Http\Controllers\API\Auth\AuthController;
use App\Http\Controllers\API\Auth\ForgotPasswordController;
use App\Http\Controllers\API\Auth\ResetPasswordController;
use App\Http\Controllers\API\BookingController;
use App\Http\Controllers\API\CarController;
use App\Http\Controllers\API\CarSpecificationController;
use App\Http\Controllers\API\ServiceAdmin\MechanicController;
use App\Http\Controllers\API\ServiceAdmin\OperatingHoursController;
use App\Http\Controllers\API\ServiceAdmin\ServiceController;
use App\Http\Controllers\API\ServiceHistoryController;
use App\Models\User;
use Illuminate\Auth\Events\Verified;
use Illuminate\Foundation\Auth\EmailVerificationRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Route;

Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

Route::post('/password/forgot', [ForgotPasswordController::class, 'sendResetLink']);
Route::post('/password/reset', [ResetPasswordController::class, 'reset']);

Route::post('/refresh', [AuthController::class, 'refresh']);
Route::get('/me', [AuthController::class, 'me']);
Route::post('/logout', [AuthController::class, 'logout']);
Route::get('/stations/popular', [ServiceStationController::class, 'popularStations']);

Route::post('/email/verification-notification', function (Request $request) {
    if ($request->user()->hasVerifiedEmail()) {
        return response()->json(['message' => 'Email already verified'], 200);
    }
    $request->user()->sendEmailVerificationNotification();

    return response()->json(['message' => 'Verification link sent']);
})->middleware(['auth:api', 'throttle:6,1'])->name('verification.send');

Route::get('/email/verify/{id}/{hash}', function ($id, $hash, Request $request) {
    $user = User::findOrFail($id);

    if (!hash_equals((string) $hash, sha1($user->getEmailForVerification()))) {
        return response()->json(['message' => 'Invalid verification link'], 403);
    }

    if ($user->hasVerifiedEmail()) {
       return Redirect::to('http://localhost:3000/email-already-verified');
    }

    $user->markEmailAsVerified();
    event(new Verified($user));

    return Redirect::to('http://localhost:3000/register/email-verified');
})->middleware(['signed'])->name('verification.verify');

Route::middleware('auth:api')->group(function () {
    Route::middleware('is_admin')->prefix('admin')->group(function () {
        Route::get('/dashboard', [AdminController::class, 'index']);
        Route::get('/users', [AdminController::class, 'getTechAdmins']);
        Route::patch('/users/{userId}/role', [AdminController::class, 'updateUserRole']);

        Route::post('/stations', [ServiceStationController::class, 'store']);
        Route::get('/stations', [ServiceStationController::class, 'index']);
        Route::put('/stations/{id}', [ServiceStationController::class, 'update']);
        Route::delete('/stations/{id}', [ServiceStationController::class, 'destroy']);
    });

    Route::middleware('role:admin_sto')->prefix('admin-sto')->group(function () {
        Route::get('/station', [ServiceStationController::class, 'myStation']);

        Route::get('/station/hours', [OperatingHoursController::class, 'index']);
        Route::post('/station/hours', [OperatingHoursController::class, 'store']);
        Route::put('/station/hours/{id}', [OperatingHoursController::class, 'update']);
        Route::delete('/station/hours/{id}', [OperatingHoursController::class, 'destroy']);

        Route::get('/mechanics', [MechanicController::class, 'getMechanics']);
        Route::get('/mechanics/{id}/schedule', [MechanicController::class, 'getSchedule']);
        Route::get('/mechanics/schedule/{id}', [MechanicController::class, 'getSingleSchedule']);
        Route::get('/mechanic-users', [MechanicController::class, 'getMechanicUsers']);
        Route::post('/mechanics', [MechanicController::class, 'store']);
        Route::post('/mechanics/schedule', [MechanicController::class, 'storeSchedule']);
        Route::put('/mechanics/schedule/{id}', [MechanicController::class, 'updateSchedule']);
        Route::delete('/mechanics/schedule/{id}', [MechanicController::class, 'deleteSchedule']);

        Route::post('/services', [ServiceController::class, 'store']);
        Route::get('/services', [ServiceController::class, 'index']);
        Route::put('/services/{id}', [ServiceController::class, 'update']);
        Route::delete('/services/{id}', [ServiceController::class, 'destroy']);
    });

    Route::middleware('role:mechanic')->prefix('mechanic')->group(function () {
        Route::get('/profile', [MechanicController::class, 'profile']);
        Route::get('/bookings', [MechanicController::class, 'myBookings']);
        Route::get('/bookings/{bookingId}', [MechanicController::class, 'bookingDetails']);
        Route::patch('/bookings/{bookingId}/status', [MechanicController::class, 'updateBookingStatus']);
        Route::get('/schedule', [MechanicController::class, 'mySchedule']);
        Route::post('/service-history', [ServiceHistoryController::class, 'store']);
    });
});

Route::middleware(['auth:api', 'verified'])->group(function (){
    Route::prefix('cars')->group(function () {
        Route::get('/', [CarController::class, 'index']);
        Route::post('/', [CarController::class, 'store']);
        Route::put('/{id}', [CarController::class, 'update']);
        Route::delete('/{id}', [CarController::class, 'destroy']);

        Route::post('/{car_id}/specifications', [CarSpecificationController::class, 'store']);
        Route::get('/{car_id}/specifications', [CarSpecificationController::class, 'show']);
        Route::put('/{car_id}/specifications', [CarSpecificationController::class, 'update']);
        Route::delete('/{car_id}/specifications', [CarSpecificationController::class, 'destroy']);

        Route::get('/service-history', [ServiceHistoryController::class, 'index']);
    });

    Route::prefix('stations')->group(function () {
        Route::get('/', [ServiceStationController::class, 'index']);
        Route::get('{stationId}/services', [ServiceController::class, 'publicServices']);
        Route::get('/search', [ServiceStationController::class, 'search']);
    });

    Route::prefix('bookings')->group(function () {
        Route::post('/', [BookingController::class, 'store']);
        Route::get('/', [BookingController::class, 'index']);
        Route::get('/{id}', [BookingController::class, 'show']);
        Route::delete('/{id}', [BookingController::class, 'destroy']);
    });
});
