<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'role' => \App\Http\Middleware\RoleMiddleware::class,
            'is_admin' => \App\Http\Middleware\IsAdmin::class,
            'verified' => \Illuminate\Auth\Middleware\EnsureEmailIsVerified::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        $exceptions->renderable(function (\Illuminate\Auth\AuthenticationException $e, $request) {
            return response()->json([
                'error' => 'Unauthorized access. Log in to continue'
            ], 401);
        });

        $exceptions->renderable(function (\Illuminate\Auth\Access\AuthorizationException $e, $request) {
            return response()->json([
                'error' => 'Access forbidden'
            ], 403);
        });

        $exceptions->renderable(function (\Illuminate\Validation\ValidationException $e, $request) {
            return response()->json([
                'errors' => $e->errors()
            ], 422);
        });

        $exceptions->renderable(function (\Illuminate\Database\Eloquent\ModelNotFoundException $e, $request) {
            return response()->json([
                'error' => 'Page not found'
            ], 404);
        });

        $exceptions->renderable(function (TokenExpiredException $e, $request) {
            return response()->json(['error' => 'Session expired. Please log in again.'], 401);
        });

        $exceptions->renderable(function (TokenInvalidException $e, $request) {
            return response()->json(['error' => 'Invalid token.'], 401);
        });

        $exceptions->renderable(function (JWTException $e, $request) {
            return response()->json(['error' => 'Token not found or corrupted.'], 401);
        });

    })->create();
