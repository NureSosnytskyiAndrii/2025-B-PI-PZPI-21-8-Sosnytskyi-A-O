<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Web_Programming\Laravel\autoservice_booking\autoservice_booking\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>