<?php echo e($slot); ?>

<?php /**PATH C:\Web_Programming\Laravel\autoservice_booking\autoservice_booking\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>